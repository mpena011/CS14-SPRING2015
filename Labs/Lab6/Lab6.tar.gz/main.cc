////////////////Information//////////////////
// Name: Michael Pena
// SID: 861167712
// Date: May 19 2015
// Approach: main for lab 6
/////////////////////////////////////////////
#include "selectionsort.h"
#include <iostream>
#include <vector>
#include <list>

using namespace std;

int main() {
    ////Vector test
    vector<int> test;
    test.push_back(2);
    test.push_back(4);
    test.push_back(5);
    test.push_back(1);
    test.push_back(8);
    test.push_back(9);
    cout << "Pre: ";
    for (unsigned i = 0; i < test.size(); ++i) {
        cout << test.at(i) << " ";
    }
    cout << endl;
    selectionsort(test);
    cout << "Post: ";
    for (unsigned i = 0; i < test.size(); ++i) {
        cout << test.at(i) << " ";
    }
    cout << endl;
    
    ////Empty Test
    list<int> test2;
    cout << "Pre: ";
    for (auto it = test2.begin(); it != test2.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
    selectionsort(test2);
    cout << "Post: ";
    for (auto it = test2.begin(); it != test2.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
    
    ////Pair Test
    vector< pair<int,int> > v;
    v.push_back(pair<int,int>(1,2));
    v.push_back(pair<int,int>(3,-1));
    v.push_back(pair<int,int>(-1,3));
    v.push_back(pair<int,int>(0,0));
    v.push_back(pair<int,int>(2,3));
    v.push_back(pair<int,int>(1,2));
    v.push_back(pair<int,int>(1,-2));
    v.push_back(pair<int,int>(8,10));
    cout << "Pre: ";
    for (auto it = v.begin(); it != v.end(); ++it) {
        cout << "(" << it->first << "," << it->second << ") ";
    }
    cout << endl;
    selectionsort(v);
    cout << "Post: ";
    for (auto it = v.begin(); it != v.end(); ++it) {
        cout << "(" << it->first << "," << it->second << ") ";
    }
    cout << endl;
    //By using the swap function, there are no copies created
    //Using the moves counter variable, the moves for this is 18
    cout << "0 copies and 18 moves" << endl;
    
    ////Second Pair Test
    vector< pair<int,int> > v2;
    v2.push_back(pair<int,int>(10,2));
    v2.push_back(pair<int,int>(-3,-1));
    v2.push_back(pair<int,int>(-8,0));
    v2.push_back(pair<int,int>(1,1));
    v2.push_back(pair<int,int>(1,1));
    v2.push_back(pair<int,int>(0,0));
    v2.push_back(pair<int,int>(10,2));
    v2.push_back(pair<int,int>(5,5));
    v2.push_back(pair<int,int>(5,-5));
    v2.push_back(pair<int,int>(0,0));
    v2.push_back(pair<int,int>(10,2));
    cout << "Pre: ";
    for (auto it = v2.begin(); it != v2.end(); ++it) {
        cout << "(" << it->first << "," << it->second << ") ";
    }
    cout << endl;
    selectionsort(v2);
    cout << "Post: ";
    for (auto it = v2.begin(); it != v2.end(); ++it) {
        cout << "(" << it->first << "," << it->second << ") ";
    }
    cout << endl;
    //By using the swap function, there are no copies created
    //Using the moves counter variable, the moves for this is 15
    cout << "0 copies and 15 moves" << endl;
    
    ////Third Pair Test
    vector< pair<int,int> > v3;
    v3.push_back(pair<int,int>(-1,3));
    v3.push_back(pair<int,int>(0,0));
    v3.push_back(pair<int,int>(1,-2));
    v3.push_back(pair<int,int>(1,2));
    v3.push_back(pair<int,int>(1,2));
    v3.push_back(pair<int,int>(2,3));
    v3.push_back(pair<int,int>(3,-1));
    v3.push_back(pair<int,int>(8,10));
    cout << "Pre: ";
    for (auto it = v3.begin(); it != v3.end(); ++it) {
        cout << "(" << it->first << "," << it->second << ") ";
    }
    cout << endl;
    selectionsort(v3);
    cout << "Post: ";
    for (auto it = v3.begin(); it != v3.end(); ++it) {
        cout << "(" << it->first << "," << it->second << ") ";
    }
    cout << endl;
    //By using the swap function, there are no copies created
    //Using the moves counter variable, the moves for this is 0
    cout << "0 copies and 0 moves" << endl;
    
    /*
    ////Test for part b
    // vector<int> testing;
    // vector<int*> address;
    // int x = 5;
    // int y = 5;
    // int w = 2;
    // int z = 1;
    // int* y_ptr = &y;
    // int* x_ptr = &x;
    // int* w_ptr = &w;
    // int* z_ptr = &z;
    // cout << endl << "Addresses: " << endl;
    // cout << "X Address: " << x_ptr << endl;
    // cout << "Y Address: " << y_ptr << endl;
    // cout << "W Address: " << w_ptr << endl;
    // cout << "Z Address: " << z_ptr << endl;
    // testing.push_back(x);
    // testing.push_back(y);
    // testing.push_back(w);
    // testing.push_back(z);
    // address.push_back(x_ptr);
    // address.push_back(y_ptr);
    // address.push_back(w_ptr);
    // address.push_back(z_ptr);
    // for (unsigned i = 0; i < testing.size(); ++i) {
    //     cout << "Value: " << testing.at(i) << endl;
    //     cout << "Address: " << address.at(i) << endl;
    // }
    // cout << endl;
    // selectsort(testing,address);
    // for (unsigned i = 0; i < testing.size(); ++i) {
    //     cout << "Value: " << testing.at(i) << endl;
    //     cout << "Address: " << address.at(i) << endl;
    // }
    */
    
    
    
    return 0;
}