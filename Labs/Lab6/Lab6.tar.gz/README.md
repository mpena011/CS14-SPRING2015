Exercise 2:
Part A:
My selection sort is not stable.
Assuming a list of: 5 5 2 1
The first 5 at index 0 and the second 5 at index 1 will be placed
in the wrong order in the final sorted set.
Assume x to be the first 5 and y to be the second 5
The steps for sorting will go as follows
x y 2 1
1 y 2 x
1 2 y x
1 2 y x
As you can see, even though the original list had the first 5 be x
and the second 5 to be y, we ended up with y being first and x being second.
A stable sort would have ensure the list ended up as
1 2 x y, not 1 2 y x like it did.


Part B:
Part A shows this and is my basis.
Assume a selectionsort function that takes in 2 containers instead of just 1.
The first container will hold the values like the one passed in our 
selectionsort function while the second holds addresses for the variables
passed into the vector. The function will perform the normal sort on the first
container and for each sort, it will also swap the positions in the address
container.

My new selection sort looks like this, renamed to selectsort, and only takes
in vectors to allow for easier traversing and swapping

void selectsort(vector<int> & v, vector<int*> & address) {
    for (unsigned i = 0; i < v.size(); ++i) {
        int lowest = v.at(i);
        int position = i;
        for (unsigned j = i; j < v.size(); ++j) {
            if (v.at(j) < lowest) {
                lowest = v.at(j);
                position = j;
            }
        }
        if (v.at(i) != lowest) {
            swap(v.at(i), v.at(position));
            swap(address.at(i), address.at(position));
        }
        
    }
}

Using the main, I created four separate int values named x,y,w,z and four 
pointers to their addresses, x_ptr,y_ptr,w_ptr, and z_ptr.
In a test run the following was output for the addresses at the start.

X Address: 0x7fff80e28df0
Y Address: 0x7fff80e28df4
W Address: 0x7fff80e28df8
Z Address: 0x7fff80e28dfc

Setting the pointers equal to the addresses so the pointer variables now store
these addresses accordingly.
I then created two separate vectors to store the values in one and addresses
in the other. The values vector looked like
5   (x)
5   (y)
2   (w)
1   (z)
(parentheses show the corresponding variable)

and the addresses vector looked like (the corresponding values in parentheses)
0x7fff80e28df0      (x,5)
0x7fff80e28df4      (y,5)
0x7fff80e28df8      (w,2)
0x7fff80e28dfc      (z,1)

as both push_back in the same order of x y w z.
Calling the selectsort function and passing these vectors in, we get a result
of our values vector to look like
1   (z)
2   (w)
5   (?)
5   (?)
(parentheses show the corresponding variable, ? refers to the fact that we
don't know yet)

but more importantly our address vector looked like
0x7fff80e28dfc      (z,1)
0x7fff80e28df8      (w,2)
0x7fff80e28df4      (y,5)
0x7fff80e28df0      (x,5)

As you can see, the x and y are in the wrong order. To be a stable sort, the 
order should be z w x y as the x was first in the list, then the y. Instead
we have the order z w y x. Thus, the function is not stable.
