////////////////Information//////////////////
// Name: Michael Pena
// SID: 861167712
// Date: May 19 2015
// Approach: Header file for lab 6
/////////////////////////////////////////////
#ifndef _SELECTIONSORT_H_
#define _SELECTIONSORT_H_

#include <utility>
#include <vector>
using namespace std;

template <typename L>
void selectionsort(L & l) {
    unsigned moves = 0;
    for (auto it = l.begin(); it != l.end(); ++it) {
        auto lowest = it;
        for (auto secondit = it; secondit != l.end(); ++secondit) {
            if (*secondit < *lowest) {
                lowest = secondit;
            }
        }
        if (*it != *lowest) {
            moves += 3;
            swap(*it, *lowest);
        }
    }
}

#endif